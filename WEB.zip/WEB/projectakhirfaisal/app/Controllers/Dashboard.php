<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    function __construct()
    {
        $this->model = new \App\Models\ModelMahasiswa();
    }
    public function hapus($id)
    {
        $this->model->delete($id);
        return redirect()->to('dashboard');
    }
    public function edit($id)
    {
        return json_encode($this->model->find($id));
    }
    public function logout()
    {
        return redirect()->to('/');
    }

    public function simpan()
    {
        $validasi  = \Config\Services::validation();
        $aturan = [
            'username' => [
                'label' => 'Username',
                'rules' => 'required|min_length[5]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 5 karakter'
                ]

            ],
            'password' => [
                'label' => 'Password',
                'rules' => 'required|min_length[5]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 5 karakter'
                ]
            ],
        ];

        $validasi->setRules($aturan);
        if ($validasi->withRequest($this->request)->run()) {
            $id = $this->request->getPost('id');
            $username = $this->request->getPost('username');
            $password = $this->request->getPost('password');
            $nama = $this->request->getPost('nama');
            $alamat = $this->request->getPost('alamat');
            $nilai_unbk = $this->request->getPost('nilai_unbk');
            $nilai_raport = $this->request->getPost('nilai_raport');
            $telpon = $this->request->getPost('telpon');
            $keterangan = $this->request->getPost('keterangan');

            $data = [
                'id' => $id,
                'username' => $username,
                'password' => $password,
                'nama' => $nama,
                'alamat' => $alamat,
                'nilai_unbk' => $nilai_unbk,
                'nilai_raport' => $nilai_raport,
                'telpon' => $telpon,
                'keterangan' => $keterangan,

            ];

            $this->model->save($data);

            $hasil['sukses'] = "Berhasil memasukkan data";
            $hasil['error'] = true;
        } else {
            $hasil['sukses'] = false;
            $hasil['error'] = $validasi->listErrors();
        }


        return json_encode($hasil);
    }
    public function index()
    {
        $jumlahBaris = 5;
        $katakunci = $this->request->getGet('katakunci');
        if ($katakunci) {
            $pencarian = $this->model->cari($katakunci);
        } else {
            $pencarian = $this->model;
        }
        $data['katakunci'] = $katakunci;
        $data['dataMahasiswa'] = $pencarian->orderBy('id', 'desc')->paginate($jumlahBaris);
        $data['pager'] = $this->model->pager;
        $data['nomor'] = ($this->request->getVar('page') == 1) ? '0' : $this->request->getVar('page');
        return view('dashboard_view', $data);
    }
}
