<?php

namespace App\Controllers;

class Login extends BaseController
{
    public function index()
    {

        $ModelLogin = new \App\Models\ModelLogin();
        $login = $this->request->getPost('login');
        if ($login) {
            $username = $this->request->getPost('username');
            $password = $this->request->getPost('password');

            if ($username == '' or $password == '') {
                $err = "Silahkan Masukan Username dan Passsword";
            }
            if (empty($err)) {
                $dataLogin = $ModelLogin->where("username", $username)->first();
                if ($dataLogin["password"] != md5($password)) {
                    $err = "Password Tidak sesuai";
                }
            }
            if (empty($err)) {
                $dataSesi = [
                    'id' => $dataLogin['id'],
                    'username' => $dataLogin['username'],
                    'password' => $dataLogin['password'],

                ];
                session()->set($dataSesi);
                return redirect()->to('/dashboard');
            }
            if ($err) {
                session()->setFlashdata('error', $err);
                return redirect()->to('/');
            }
        }
        return view('login_view');
    }
}
