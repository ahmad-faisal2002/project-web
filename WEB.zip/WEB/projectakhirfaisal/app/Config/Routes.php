<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
#$routes->get('/', 'Home::index');
$routes->get('/', 'Login::index');
$routes->post('/', 'Login::index');
$routes->get('/dashboard', 'Dashboard::index');

$routes->get('/dashboard', 'Dashboard::index');
$routes->post('/dashboard/simpan', 'Dashboard::simpan');
$routes->get('/dashboard/simpan', 'Dashboard::simpan');
$routes->get('/dashboard/hapus/(:segment)', 'Dashboard::hapus/$1');
$routes->get('/dashboard/edit/(:segment)', 'Dashboard::edit/$1');
$routes->get('/dashboard/katakunci/(:segment)', 'Dashboard::katakunci/$1');
$routes->get('/dashboard/page/(:segment)', 'Dashboard::page/$1');
$routes->get('/dashboard/logout', 'Dashboard::logout');
