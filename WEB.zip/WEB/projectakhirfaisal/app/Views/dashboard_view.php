<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <style>
        * body {
            background-color: burlywood;
        }

        .container {
            margin-top: 20px;
        }

        .table {
            font-size: small;
            font-family: cursive;
        }

        .modal-body {
            font-size: 11px;
        }
    </style>
</head>

<body>
    <!-- CONTAINER -->
    <div class="container">
        <!-- CARD -->
        <div class="card">
            <div class="card-header bg-secondary text-white">
                Data Mahasiswa
            </div>
            <div class="card-body">
                <!-- LOKASI TEXT Search -->
                <form action="" method="get">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" value="<?php echo $katakunci ?>" name="katakunci" placeholder="Masukkan Kata Kunci" aria-label="Masukkan Kata Kunci" aria-describedby="button-addon2">
                        <button class="btn btn-outline-secondary" type="submit" id="button-addon2">Cari</button>
                    </div>
                </form>
                <!-- MODAL -->
                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    + Tambah Data Mahasiswa
                </button>
                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Form Mahasiswa</h5>
                                <button type="button" class="btn-close tombol-tutup" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <!-- KALAU ERROR -->
                                <div class="alert alert-danger error" role="alert" style="display: none;">
                                </div>
                                <!-- KALAU SUKSES -->
                                <div class="alert alert-primary sukses" role="alert" style="display: none;">
                                </div>
                                <!-- FORM INPUT DATA -->
                                <input type="hidden" id="inputId">
                                <div class="mb-3 row">
                                    <label for="inputUsername" class="col-sm-2 col-form-label">Username</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputUsername">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputNama" class="col-sm-2 col-form-label">Nama</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputNama">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputAlamat" class="col-sm-2 col-form-label">Alamat</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputAlamat">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputUnbk" class="col-sm-2 col-form-label">Nilai Rata-Rata UNBK</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputUnbk">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputRaport" class="col-sm-2 col-form-label">Nilai Rata-Rata Raport</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputRaport">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputHp" class="col-sm-2 col-form-label">No Telpon</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputHp">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputKeterangan" class="col-sm-2 col-form-label">Keterangan</label>
                                    <div class="col-sm-10">
                                        <select id="inputKeterangan" class="form-select">
                                            <option value="Belum Ada Keterangan">---</option>
                                            <option value="Lulus">Lulus</option>
                                            <option value="Tidak Lulus">Tidak Lulus</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary tombol-tutup" data-bs-dismiss="modal">Tutup</button>
                                <button type="button" class="btn btn-primary" id="tombolSimpan">Simpan</button>
                            </div>
                        </div>
                    </div>
                </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Nilai UNBK</th>
                            <th>Nilai Raport</th>
                            <th>No Hp.</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="tubuh">
                        <?php
                        foreach ($dataMahasiswa as $k => $v) {
                            $nomor = $nomor + 1;
                        ?>
                            <tr>
                                <td><?php echo $nomor ?></td>
                                <td><?php echo $v['username'] ?></td>
                                <td><?php echo $v['password'] ?></td>
                                <td><?php echo $v['nama'] ?></td>
                                <td><?php echo $v['alamat'] ?></td>
                                <td><?php echo $v['nilai_unbk'] ?></td>
                                <td><?php echo $v['nilai_raport'] ?></td>
                                <td><?php echo $v['telpon'] ?></td>
                                <td><?php echo $v['keterangan'] ?></td>
                                <td>
                                    <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="edit(<?php echo $v['id'] ?>)">Set</button>
                                    <button type="button" class="btn btn-danger btn-sm" onclick="hapus(<?php echo $v['id'] ?>)">Delete</button>

                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>

                </table>
                <?php
                $linkPagination = $pager->links();
                $linkPagination = str_replace('<li class="active">', '<li class="page-item active">', $linkPagination);
                $linkPagination = str_replace('<li>', '<li class="page-item">', $linkPagination);
                $linkPagination = str_replace("<a", "<a class='page-link'", $linkPagination);
                echo $linkPagination;
                ?>
            </div>
            <a href="<?php echo site_url('dashboard/logout') ?>" class="btn btn-danger">Logout</a>
        </div>

    </div>
    <!-- SCRIPT JAVASCRIPT -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

    <script>
        function hapus($id) {
            var result = confirm('Yakin mau melakukan proses delete');
            if (result) {
                window.location = "<?php echo site_url("dashboard/hapus") ?>/" + $id;
            }
        }

        function edit($id) {
            $.ajax({
                url: "<?php echo site_url("dashboard/edit") ?>/" + $id,
                type: "get",
                success: function(hasil) {
                    var $obj = $.parseJSON(hasil);
                    if ($obj.id != '') {
                        $('#inputId').val($obj.id);
                        $('#inputUsername').val($obj.username);
                        $('#inputPassword').val($obj.password);
                        $('#inputNama').val($obj.nama);
                        $('#inputAlamat').val($obj.alamat);
                        $('#inputUnbk').val($obj.nilai_unbk);
                        $('#inputRaport').val($obj.nilai_raport);
                        $('#inputHp').val($obj.telpon);
                        $('#inputKeterangan').val($obj.keterangan);
                    }
                }

            });
        }

        function bersihkan() {
            $('#inputUsername').val('');
            $('#inputPassword').val('');
            $('#inputNama').val('');
            $('#inputAlamat').val('');
            $('#inputUnbk').val('');
            $('#inputRaport').val('');
            $('#inputHp').val('');
            $('#inputKeterangan').val('');
        }
        $('.tombol-tutup').on('click', function() {
            if ($('.sukses').is(":visible")) {
                window.location.href = "<?php echo current_url() . "?" . $_SERVER['QUERY_STRING'] ?>";
            }
            $('.alert').hide();
            bersihkan();
        });

        $('#tombolSimpan').on('click', function() {
            var $id = $('#inputId').val();
            var $username = $('#inputUsername').val();
            var $password = $('#inputPassword').val();
            var $nama = $('#inputNama').val();
            var $alamat = $('#inputAlamat').val();
            var $nilai_unbk = $('#inputUnbk').val();
            var $nilai_raport = $('#inputRaport').val();
            var $telepon = $('#inputHp').val();
            var $keterangan = $('#inputKeterangan').val();

            $.ajax({
                url: "<?php echo site_url("dashboard/simpan") ?>",
                type: "POST",
                data: {
                    id: $id,
                    username: $username,
                    password: $password,
                    nama: $nama,
                    alamat: $alamat,
                    nilai_unbk: $nilai_unbk,
                    nilai_raport: $nilai_raport,
                    telpon: $telepon,
                    keterangan: $keterangan

                },
                success: function(hasil) {
                    var $obj = $.parseJSON(hasil);
                    if ($obj.sukses == false) {
                        $('.sukses').hide();
                        $('.error').show();
                        $('.error').html($obj.error);
                    } else {
                        $('.error').hide();
                        $('.sukses').show();
                        $('.sukses').html($obj.sukses);
                    }
                }
            });
            bersihkan();

        });
    </script>
</body>

</html>