<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelMahasiswa extends Model
{
    protected $table = "mahasiswa";
    protected $primaryKey = "id";
    protected $allowedFields = ['username', 'password', 'nama', 'alamat', 'nilai_unbk', 'nilai_raport', 'telpon', 'keterangan'];

    function cari($katakunci)
    {
        $builder = $this->table("mahasiswa");
        $arr_katakunci = explode(" ", $katakunci);
        for ($x = 0; $x < count($arr_katakunci); $x++) {
            $builder->orLike('nama', $arr_katakunci[$x]);
            $builder->orLike('username', $arr_katakunci[$x]);
            #$builder->orLike('nilai', $arr_katakunci[$x]);
        }
        return $builder;
    }
}
