-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 31 Des 2023 pada 05.16
-- Versi server: 10.4.20-MariaDB
-- Versi PHP: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projectakhirfaisal`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'ixsal', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `id` int(11) NOT NULL,
  `username` varchar(33) NOT NULL,
  `password` varchar(33) NOT NULL,
  `nama` varchar(33) NOT NULL,
  `alamat` varchar(33) NOT NULL,
  `nilai_unbk` varchar(33) NOT NULL,
  `nilai_raport` varchar(33) NOT NULL,
  `telpon` varchar(33) NOT NULL,
  `keterangan` varchar(33) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`id`, `username`, `password`, `nama`, `alamat`, `nilai_unbk`, `nilai_raport`, `telpon`, `keterangan`) VALUES
(6, 'ramlanbgn', '1212', 'Ramlan', 'Desa Bungin Rt1', '80', '90', '9872626262626', 'Lulus'),
(7, 'masjamrt1', '32311', 'Masjam', 'Desa Bungin Rt1', '90', '90', '120980801', 'Tidak Lulus'),
(8, 'fauzi', '123', 'Ahmad Fauzi', 'Desa Kndangan', '90', '90', '0859196435239', 'Belum Ada Keterangan'),
(10, 'hambalibgn', '123', 'HAMBALI', 'desa Riwa', '100', '0', '859196435239', 'Tidak Lulus'),
(11, 'Arbayahbgn', 'arbayah', 'Arbayah', 'Desa Jungkal', '100', '60', '087652426162752711', 'Belum Ada Keterangan'),
(13, 'ahimrt01', 'orangparingin', 'Ahim', 'Desa layap', '0', '0', '80', 'Lulus'),
(17, 'faisaluwu', 'uwu123', 'Faisal Fauzi', 'Bungin uwu', '100', '100', '859196435239', 'Lulus');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
