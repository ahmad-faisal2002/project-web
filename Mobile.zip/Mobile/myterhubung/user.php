<?php
require_once('koneksi.php');

//INSERT DATA
if ((isset($_POST['MM_insert'])) && ($_POST['MM_insert'] == "oiaya")) {

    $insertSQL = sprintf(
        "INSERT INTO `mahasiswa` (`nama`, `telpon`, `alamat`,`username`, `password`, `nilai_raport`, `nilai_unbk`) VALUES (%s, %s, %s, %s, %s, %s, %s)",
        app($koneksi, $_POST['nama'], "text"),
        app($koneksi, $_POST['telpon'], "text"),
        app($koneksi, $_POST['alamat'], "text"),
        app($koneksi, $_POST['username'], "text"),
        app($koneksi, $_POST['password'], "text"),
        app($koneksi, $_POST['nilai_raport'], "text"),
        app($koneksi, $_POST['nilai_unbk'], "text")
    );

    $Result1 = mysqli_query($koneksi, $insertSQL) or die(mysqli_error($koneksi));


    if ($Result1) {
        $response['kode'] = 1;
        $response['pesan'] = "Data berhasil disimpan";
    } else {
        $response['kode'] = 0;
        $response['pesan'] = "Data gagal disimpan";
    }

    echo json_encode($response);
    mysqli_close($koneksi);
}


//VIEW DATA
if ((isset($_GET['MM_view'])) && ($_GET['MM_view'] == "oiaya")) {
    $id = "-1";
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
    }
    $query = sprintf(
        "SELECT * FROM mahasiswa WHERE id=%s",
        app($koneksi, $id, "int")
    );


    $data = mysqli_query($koneksi, $query) or die(mysqli_error($koneksi));
    $rs_data = mysqli_fetch_assoc($data);
    $ResultData = mysqli_num_rows($data);

    if ($ResultData > 0) {

        $response['kode'] = 1;
        $response['pesan'] = "Data Tersedia";
        $response['data'] = array();
        foreach ($data as $user) {
            $arr['id'] = $user['id'];
            $arr['nama'] = $user['nama'];
            $arr['telpon'] = $user['telpon'];
            $arr['alamat'] = $user['alamat'];
            $arr['nilai_unbk'] = $user['nilai_unbk'];
            $arr['nilai_raport'] = $user['nilai_raport'];
            $arr['keterangan'] = $user['keterangan'];
            array_push($response['data'], $arr);
        }
    } else {
        $response['kode'] = 0;
        $response['pesan'] = "Data tidak ditemukan!";
    }

    echo json_encode($response);
    mysqli_close($koneksi);
}
